"use client";

import { useState } from "react";
import AppShell from "@/components/AppShell";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  heartRateTrend,
  bloodPressureTrend,
  sleepTrend,
  activityTrend,
  diseaseRiskTrend,
} from "@/lib/data";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

const ranges = ["Weekly", "Monthly", "Yearly"];

export default function AnalyticsPage() {
  const [range, setRange] = useState("Weekly");

  return (
    <AppShell>
      <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Health Analytics</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Deep insights into your long-term health trends.</p>
        </div>
        <div className="flex gap-1 rounded-full bg-gray-100 p-1">
          {ranges.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={cn(
                "rounded-full px-4 py-1.5 text-xs font-semibold transition-colors",
                range === r ? "bg-white text-primary shadow-sm" : "text-gray-500"
              )}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Heart Rate Trend ({range})</CardTitle></CardHeader>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={heartRateTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <YAxis axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <CardHeader><CardTitle>Blood Pressure Trend ({range})</CardTitle></CardHeader>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={bloodPressureTrend}>
              <defs>
                <linearGradient id="bpGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10B981" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <YAxis axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#10B981" fill="url(#bpGradient)" strokeWidth={2.5} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <CardHeader><CardTitle>Sleep Trend ({range})</CardTitle></CardHeader>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={sleepTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <YAxis axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Bar dataKey="value" fill="#2563EB" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <CardHeader><CardTitle>Activity Trend ({range})</CardTitle></CardHeader>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={activityTrend}>
              <defs>
                <linearGradient id="actGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <YAxis axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#2563EB" fill="url(#actGradient)" strokeWidth={2.5} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Disease Risk Trend (Yearly)</CardTitle></CardHeader>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={diseaseRiskTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <YAxis axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#10B981" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </AppShell>
  );
}
