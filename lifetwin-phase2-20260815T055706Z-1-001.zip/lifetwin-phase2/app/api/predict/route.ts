import { NextResponse } from "next/server";
import { diseaseRisks } from "@/lib/data";

// Sample API route: POST /api/predict
// In production this would call an ML model with the user's vitals + history.
export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  return NextResponse.json({
    success: true,
    input: body,
    predictions: diseaseRisks,
  });
}
