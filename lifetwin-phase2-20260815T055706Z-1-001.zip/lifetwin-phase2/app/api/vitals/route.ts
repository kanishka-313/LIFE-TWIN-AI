import { NextResponse } from "next/server";
import { vitalStats } from "@/lib/data";

// Sample API route: GET /api/vitals
// Returns current vital signs for the authenticated user's digital twin.
export async function GET() {
  return NextResponse.json({ success: true, data: vitalStats });
}
