"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { initialChat, chatSuggestions } from "@/lib/data";
import type { ChatMessage } from "@/types";
import { Bot, Mic, Paperclip, FileText, Send, Sparkles } from "lucide-react";

function aiReply(question: string): string {
  const q = question.toLowerCase();
  if (q.includes("heart rate")) return "Your heart rate rose slightly after your 6 PM workout, which is expected. It has since returned to your normal resting range of 68–76 bpm.";
  if (q.includes("blood report") || q.includes("report")) return "Your latest blood report shows normal glucose, cholesterol within range, and healthy hemoglobin levels. One marker — Vitamin D — is slightly low, so consider more sunlight or a supplement.";
  if (q.includes("diet")) return "Based on your goals, I'd suggest a Mediterranean-style plan: lean protein, leafy greens, whole grains, and healthy fats. I can generate a full 7-day meal plan if you'd like.";
  if (q.includes("exercise")) return "Yes! Your vitals look great today — heart rate, sleep, and stress levels are all in the normal range. A moderate 30–40 minute session is a good idea.";
  return "Thanks for your question. Based on your current digital twin data, everything looks within a healthy range. Let me know if you'd like a deeper breakdown.";
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialChat);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "ai",
          content: aiReply(text),
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
      setTyping(false);
    }, 1400);
  };

  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">AI Health Assistant</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Ask anything about your vitals, reports, or wellness plan.</p>
      </div>

      <Card className="flex h-[70vh] flex-col p-0 overflow-hidden">
        <div className="flex items-center gap-3 border-b border-gray-100 p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">LifeTwin Assistant</p>
            <p className="flex items-center gap-1 text-xs text-emerald-600">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Online
            </p>
          </div>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                  m.role === "user"
                    ? "bg-gradient-to-r from-primary to-accent text-white"
                    : "bg-gray-100 text-gray-700 dark:bg-slate-800 dark:text-gray-200"
                }`}
              >
                {m.content}
                <p className={`mt-1 text-[10px] ${m.role === "user" ? "text-white/70" : "text-gray-400"}`}>{m.timestamp}</p>
              </div>
            </div>
          ))}
          <AnimatePresence>
            {typing && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex justify-start">
                <div className="flex gap-1 rounded-2xl bg-gray-100 px-4 py-3 dark:bg-slate-800">
                  {[0, 1, 2].map((d) => (
                    <span
                      key={d}
                      className="h-1.5 w-1.5 animate-bounce rounded-full bg-gray-400"
                      style={{ animationDelay: `${d * 0.15}s` }}
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={endRef} />
        </div>

        <div className="border-t border-gray-100 p-3">
          <div className="mb-3 flex flex-wrap gap-2">
            {chatSuggestions.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="flex items-center gap-1 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/10"
              >
                <Sparkles className="h-3 w-3" /> {s}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-center gap-2 rounded-2xl border border-gray-200 px-3 py-2"
          >
            <button type="button" className="text-gray-400 hover:text-primary" aria-label="Upload medical report">
              <FileText className="h-5 w-5" />
            </button>
            <button type="button" className="text-gray-400 hover:text-primary" aria-label="Attach file">
              <Paperclip className="h-5 w-5" />
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about your health..."
              className="flex-1 bg-transparent text-sm outline-none"
            />
            <button type="button" className="text-gray-400 hover:text-primary" aria-label="Voice input">
              <Mic className="h-5 w-5" />
            </button>
            <Button type="submit" size="sm" className="px-3">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </Card>
    </AppShell>
  );
}
