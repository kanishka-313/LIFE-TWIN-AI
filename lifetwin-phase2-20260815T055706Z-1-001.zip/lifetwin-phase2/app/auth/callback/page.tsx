"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import api, { setToken } from "@/lib/api";

export default function AuthCallbackPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const hash = window.location.hash.startsWith("#") ? window.location.hash.slice(1) : "";
    const params = new URLSearchParams(hash);
    const token = params.get("access_token");

    if (!token) {
      setError("Google sign-in did not return a valid session. Please try again.");
      return;
    }

    setToken(token);

    // A Google account only proves identity — it never carries health data.
    // Route first-time Google users to complete their own Health Profile
    // instead of dropping them onto a dashboard with nothing to show.
    api.health
      .getProfile()
      .then((profile) => {
        router.replace(profile ? "/dashboard" : "/health-profile");
      })
      .catch(() => {
        router.replace("/dashboard");
      });
  }, [router]);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 text-center">
      {error ? (
        <div>
          <p className="mb-4 text-sm text-red-600">{error}</p>
          <a href="/login" className="font-semibold text-primary">Back to login</a>
        </div>
      ) : (
        <p className="text-sm text-gray-500">Signing you in...</p>
      )}
    </div>
  );
}
