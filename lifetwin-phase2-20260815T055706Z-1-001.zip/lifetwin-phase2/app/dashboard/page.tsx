"use client";

import { motion } from "framer-motion";
import AppShell from "@/components/AppShell";
import VitalCard from "@/components/VitalCard";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { vitalStats, diseaseRisks, wearableDevices } from "@/lib/data";
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { heartRateTrend } from "@/lib/data";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export default function DashboardPage() {
  return (
    <AppShell>
      <div className="mb-8 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Welcome back, Alex</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Here&apos;s your AI health digital twin summary for today.
          </p>
        </div>
        <Badge status="low">All vitals normal</Badge>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {vitalStats.map((stat, i) => (
          <VitalCard key={stat.id} stat={stat} index={i} />
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Heart Rate — Live Trend</CardTitle>
            <Link href="/analytics" className="flex items-center gap-1 text-xs font-semibold text-primary">
              Full Analytics <ArrowUpRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={heartRateTrend}>
              <defs>
                <linearGradient id="hrGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="label" axisLine={false} tickLine={false} fontSize={12} />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#2563EB" fill="url(#hrGradient)" strokeWidth={2.5} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Disease Risks</CardTitle>
          </CardHeader>
          <div className="flex flex-col gap-4">
            {diseaseRisks.slice(0, 3).map((d) => (
              <div key={d.id}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium text-gray-700 dark:text-gray-200">{d.name}</span>
                  <Badge status={d.level}>{d.riskPercent}%</Badge>
                </div>
                <Progress value={d.riskPercent} level={d.level} />
              </div>
            ))}
          </div>
          <Link href="/disease-prediction" className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-primary">
            View all predictions <ArrowUpRight className="h-3 w-3" />
          </Link>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Connected Devices</CardTitle>
            <Link href="/wearables" className="flex items-center gap-1 text-xs font-semibold text-primary">
              Manage <ArrowUpRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            {wearableDevices.slice(0, 4).map((dev) => (
              <div key={dev.id} className="flex items-center justify-between rounded-2xl border border-gray-100 p-3">
                <div>
                  <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">{dev.name}</p>
                  <p className="text-xs text-gray-500">{dev.connected ? `Synced ${dev.lastSync}` : "Disconnected"}</p>
                </div>
                <Badge status={dev.connected ? "low" : "high"}>{dev.connected ? "Online" : "Offline"}</Badge>
              </div>
            ))}
          </div>
        </Card>

        <Card className="flex flex-col justify-between bg-gradient-to-br from-primary to-accent text-white">
          <div>
            <p className="text-sm font-medium text-white/80">AI Health Score</p>
            <p className="mt-2 text-5xl font-extrabold">92</p>
            <p className="mt-1 text-xs text-white/80">Better than 87% of users your age</p>
          </div>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "92%" }}
            transition={{ duration: 1 }}
            className="mt-6 h-2 rounded-full bg-white"
          />
        </Card>
      </div>
    </AppShell>
  );
}
