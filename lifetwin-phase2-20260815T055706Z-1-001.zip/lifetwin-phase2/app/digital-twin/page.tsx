"use client";

import { motion } from "framer-motion";
import AppShell from "@/components/AppShell";
import DigitalTwinHologram from "@/components/DigitalTwinHologram";
import { Card } from "@/components/ui/card";
import { digitalTwinOrgans } from "@/lib/data";

export default function DigitalTwinPage() {
  return (
    <AppShell>
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Your AI Digital Twin</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          A real-time simulation of your body, synced with your wearables.
        </p>
      </div>

      <div className="relative mx-auto max-w-3xl">
        <DigitalTwinHologram />

        <div className="absolute inset-0">
          {digitalTwinOrgans.map((organ, i) => (
            <motion.div
              key={organ.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1, duration: 0.4 }}
              className={`absolute ${organ.position} -translate-x-1/2`}
            >
              <div className="glass flex items-center gap-2 rounded-2xl border border-white/60 px-3 py-1.5 shadow-soft">
                <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
                <div className="text-left">
                  <p className="text-[10px] font-medium text-gray-500">{organ.label}</p>
                  <p className="text-xs font-bold text-gray-900 dark:text-white">{organ.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {digitalTwinOrgans.map((organ) => (
          <Card key={organ.id} className="text-center">
            <p className="text-xs font-medium text-gray-500">{organ.label}</p>
            <p className="mt-1 text-lg font-bold text-gray-900 dark:text-white">{organ.value}</p>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}
