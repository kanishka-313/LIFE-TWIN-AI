"use client";

import { motion } from "framer-motion";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { diseaseRisks } from "@/lib/data";
import { ShieldCheck, Sparkles } from "lucide-react";

export default function DiseasePredictionPage() {
  return (
    <AppShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Disease Prediction</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          AI-powered risk analysis based on your vitals, lifestyle, and history.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {diseaseRisks.map((risk, i) => (
          <motion.div
            key={risk.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
          >
            <Card className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900 dark:text-white">{risk.name}</h3>
                <Badge status={risk.level}>
                  {risk.level === "low" ? "Low Risk" : risk.level === "medium" ? "Medium Risk" : "High Risk"}
                </Badge>
              </div>

              <div className="flex items-end gap-2">
                <span className="text-4xl font-extrabold text-gray-900 dark:text-white">{risk.riskPercent}%</span>
                <span className="mb-1 text-xs text-gray-400">risk score</span>
              </div>

              <Progress value={risk.riskPercent} level={risk.level} />

              <div className="flex items-center gap-1.5 text-xs text-gray-500">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                AI Confidence: <span className="font-semibold text-gray-700 dark:text-gray-200">{risk.confidence}%</span>
              </div>

              <div className="flex items-start gap-2 rounded-2xl bg-primary/5 p-3 text-xs text-gray-600 dark:text-gray-300">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                {risk.recommendation}
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </AppShell>
  );
}
