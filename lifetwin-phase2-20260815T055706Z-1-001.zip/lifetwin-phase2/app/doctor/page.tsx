"use client";

import { useState } from "react";
import AppShell from "@/components/AppShell";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { patients, heartRateTrend } from "@/lib/data";
import { LineChart, Line, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import { Upload, Calendar, FileText } from "lucide-react";

export default function DoctorDashboardPage() {
  const [selected, setSelected] = useState(patients[0]);

  return (
    <AppShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Doctor Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Monitor and manage your patients&apos; AI digital twins.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 p-0 overflow-hidden">
          <div className="p-6 pb-0"><CardTitle>Patient List</CardTitle></div>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-y border-gray-100 text-xs text-gray-400">
                  <th className="px-6 py-3 font-medium">Patient</th>
                  <th className="px-6 py-3 font-medium">Health Score</th>
                  <th className="px-6 py-3 font-medium">Risk</th>
                  <th className="px-6 py-3 font-medium">Vitals</th>
                  <th className="px-6 py-3 font-medium">Last Visit</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((p) => (
                  <tr
                    key={p.id}
                    onClick={() => setSelected(p)}
                    className={`cursor-pointer border-b border-gray-50 transition-colors hover:bg-primary/5 ${
                      selected.id === p.id ? "bg-primary/5" : ""
                    }`}
                  >
                    <td className="px-6 py-3 font-semibold text-gray-800 dark:text-gray-100">{p.name}</td>
                    <td className="px-6 py-3">{p.healthScore}</td>
                    <td className="px-6 py-3"><Badge status={p.riskLevel}>{p.riskLevel}</Badge></td>
                    <td className="px-6 py-3 text-xs text-gray-500">{p.vitals.heartRate} bpm · {p.vitals.bp}</td>
                    <td className="px-6 py-3 text-xs text-gray-500">{p.lastVisit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle>{selected.name}</CardTitle></CardHeader>
          <div className="flex flex-col gap-3 text-sm">
            <div className="flex justify-between"><span className="text-gray-400">Age</span><span className="font-semibold">{selected.age}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Health Score</span><span className="font-semibold">{selected.healthScore}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Heart Rate</span><span className="font-semibold">{selected.vitals.heartRate} bpm</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Blood Pressure</span><span className="font-semibold">{selected.vitals.bp}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">SpO2</span><span className="font-semibold">{selected.vitals.spo2}%</span></div>
          </div>
          <div className="mt-4">
            <p className="mb-1 text-xs font-medium text-gray-400">Heart Rate Trend</p>
            <ResponsiveContainer width="100%" height={80}>
              <LineChart data={heartRateTrend}>
                <Line type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2} dot={false} />
                <Tooltip />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 flex flex-col gap-2">
            <Button size="sm" variant="outline"><Calendar className="h-4 w-4" /> Schedule Appointment</Button>
            <Button size="sm" variant="outline"><FileText className="h-4 w-4" /> View Reports</Button>
            <Button size="sm" variant="secondary"><Upload className="h-4 w-4" /> Upload Prescription</Button>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
