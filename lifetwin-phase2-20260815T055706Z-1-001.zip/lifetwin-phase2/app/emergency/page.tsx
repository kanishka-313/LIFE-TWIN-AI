"use client";

import { motion } from "framer-motion";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { emergencyTimeline } from "@/lib/data";
import { Siren, MapPin, PhoneCall, Users, Hospital, AlertTriangle } from "lucide-react";

export default function EmergencyPage() {
  return (
    <AppShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Emergency</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Live safety monitoring and one-tap emergency response.</p>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-card bg-gradient-to-br from-red-500 to-red-600 p-8 text-white shadow-lg"
      >
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex h-16 w-16 animate-pulse items-center justify-center rounded-full bg-white/20">
            <AlertTriangle className="h-8 w-8" />
          </div>
          <div>
            <p className="text-lg font-bold">Abnormal Heart Rate Alert</p>
            <p className="text-sm text-white/85">Reading of 128 bpm detected at 09:42 AM — above your normal range.</p>
          </div>
          <button className="mt-2 flex h-24 w-24 items-center justify-center rounded-full bg-white text-lg font-extrabold text-red-600 shadow-xl transition-transform hover:scale-105">
            SOS
          </button>
        </div>
      </motion.div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Live Location & Nearest Hospital</h3>
          </div>
          <div className="flex h-56 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10">
            <div className="text-center">
              <Hospital className="mx-auto mb-2 h-8 w-8 text-primary" />
              <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">City General Hospital</p>
              <p className="text-xs text-gray-500">1.8 km away · ETA 6 min</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <Button variant="danger"><PhoneCall className="h-4 w-4" /> Call Ambulance</Button>
            <Button variant="secondary"><Users className="h-4 w-4" /> Notify Family</Button>
          </div>
        </Card>

        <Card>
          <h3 className="mb-4 text-sm font-semibold text-gray-900 dark:text-white">Emergency Timeline</h3>
          <div className="flex flex-col gap-4">
            {emergencyTimeline.map((e, i) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span
                    className={`h-2.5 w-2.5 rounded-full ${
                      e.status === "success" ? "bg-emerald-500" : e.status === "warning" ? "bg-amber-500" : "bg-primary"
                    }`}
                  />
                  {i !== emergencyTimeline.length - 1 && <span className="h-full w-px flex-1 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className="text-xs text-gray-400">{e.time}</p>
                  <p className="text-sm text-gray-700 dark:text-gray-200">{e.event}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-6 flex items-center gap-2 rounded-2xl bg-amber-50 p-4 text-xs text-amber-700">
        <Siren className="h-4 w-4" /> Emergency contacts and hospitals are pre-configured in Settings.
      </div>
    </AppShell>
  );
}
