"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { HeartPulse, Mail, Lock, KeyRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import api, { ApiError } from "@/lib/api";

type Step = "email" | "otp" | "password" | "done";

export default function ForgotPasswordPage() {
  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const router = useRouter();

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.auth.forgotPassword(email);
      setInfo(res.message);
      setStep("otp");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setError(null);
    setInfo(null);
    setResending(true);
    try {
      const res = await api.auth.forgotPassword(email);
      setInfo(res.message);
      setOtp("");
    } catch (err) {
      // Includes the cooldown wait message from the backend when applicable
      // (e.g. "Please wait 42s before requesting another code").
      setError(err instanceof ApiError ? err.message : "Something went wrong");
    } finally {
      setResending(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.auth.verifyOtp(email, otp, "password_reset");
      setStep("password");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Invalid code");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.auth.resetPassword({
        email,
        otp,
        new_password: newPassword,
        confirm_new_password: confirmPassword,
      });
      setStep("done");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-white to-accent/5 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md rounded-card border border-white/60 bg-white/80 p-8 shadow-soft backdrop-blur-xl"
      >
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-soft">
            <HeartPulse className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Reset your password</h1>
          <p className="text-sm text-gray-500">
            {step === "email" && "Enter your account email to receive a code"}
            {step === "otp" && "Enter the 6-digit code we emailed you"}
            {step === "password" && "Choose a new password"}
            {step === "done" && "Your password has been updated"}
          </p>
        </div>

        {error && <div className="mb-4 rounded-xl bg-red-50 px-4 py-2 text-sm text-red-600">{error}</div>}
        {info && step !== "email" && (
          <div className="mb-4 rounded-xl bg-primary/5 px-4 py-2 text-sm text-primary">{info}</div>
        )}

        {step === "email" && (
          <form onSubmit={handleSendCode} className="flex flex-col gap-4">
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Mail className="h-4 w-4 text-gray-400" />
              <input
                type="email"
                required
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <Button type="submit" size="lg" className="mt-2 w-full" disabled={loading}>
              {loading ? "Sending code..." : "Send code"}
            </Button>
          </form>
        )}

        {step === "otp" && (
          <form onSubmit={handleVerifyOtp} className="flex flex-col gap-4">
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <KeyRound className="h-4 w-4 text-gray-400" />
              <input
                type="text"
                required
                inputMode="numeric"
                maxLength={6}
                placeholder="6-digit code"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full bg-transparent text-sm tracking-widest outline-none"
              />
            </label>
            <Button type="submit" size="lg" className="mt-2 w-full" disabled={loading}>
              {loading ? "Verifying..." : "Verify code"}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="md"
              className="w-full"
              disabled={resending}
              onClick={handleResendOtp}
            >
              {resending ? "Resending..." : "Resend OTP"}
            </Button>
          </form>
        )}

        {step === "password" && (
          <form onSubmit={handleResetPassword} className="flex flex-col gap-4">
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Lock className="h-4 w-4 text-gray-400" />
              <input
                type="password"
                required
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Lock className="h-4 w-4 text-gray-400" />
              <input
                type="password"
                required
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <Button type="submit" size="lg" className="mt-2 w-full" disabled={loading}>
              {loading ? "Updating..." : "Update password"}
            </Button>
          </form>
        )}

        {step === "done" && (
          <Button size="lg" className="w-full" onClick={() => router.push("/login")}>
            Go to login
          </Button>
        )}

        <p className="mt-6 text-center text-sm text-gray-500">
          Remembered it?{" "}
          <Link href="/login" className="font-semibold text-primary">Back to login</Link>
        </p>
      </motion.div>
    </div>
  );
}
