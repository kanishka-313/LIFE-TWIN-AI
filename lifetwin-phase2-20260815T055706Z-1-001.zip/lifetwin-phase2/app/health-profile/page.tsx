"use client";

import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserRound, Pencil } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import api, { ApiError, Gender, HealthProfile } from "@/lib/api";

const genderLabels: Record<Gender, string> = {
  male: "Male",
  female: "Female",
  other: "Other",
  prefer_not_to_say: "Prefer not to say",
};

interface FormState {
  age: string;
  gender: Gender | "";
  height_cm: string;
  weight_kg: string;
  medical_history: string;
  allergies: string;
  family_history: string;
}

const emptyForm: FormState = {
  age: "",
  gender: "",
  height_cm: "",
  weight_kg: "",
  medical_history: "",
  allergies: "",
  family_history: "",
};

function toForm(profile: HealthProfile | null): FormState {
  if (!profile) return emptyForm;
  return {
    age: String(profile.age),
    gender: profile.gender,
    height_cm: String(profile.height_cm),
    weight_kg: String(profile.weight_kg),
    medical_history: profile.medical_history ?? "",
    allergies: profile.allergies ?? "",
    family_history: profile.family_history ?? "",
  };
}

export default function HealthProfilePage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<HealthProfile | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api.health
      .getProfile()
      .then((data) => {
        if (cancelled) return;
        setProfile(data);
        setForm(toForm(data));
        // No profile yet (shouldn't normally happen post-signup) — start in edit mode.
        if (!data) setEditing(true);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof ApiError ? err.message : "Could not load health profile");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleSave = async () => {
    setError(null);

    const ageNum = Number(form.age);
    const heightNum = Number(form.height_cm);
    const weightNum = Number(form.weight_kg);

    if (!form.gender) {
      setError("Please select a gender.");
      return;
    }
    if (!Number.isFinite(ageNum) || ageNum <= 0) {
      setError("Please enter a valid age.");
      return;
    }
    if (!Number.isFinite(heightNum) || heightNum <= 0) {
      setError("Please enter a valid height.");
      return;
    }
    if (!Number.isFinite(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight.");
      return;
    }

    setSaving(true);
    try {
      const updated = await api.health.updateProfile({
        age: ageNum,
        gender: form.gender,
        height_cm: heightNum,
        weight_kg: weightNum,
        medical_history: form.medical_history || null,
        allergies: form.allergies || null,
        family_history: form.family_history || null,
      });
      setProfile(updated);
      setForm(toForm(updated));
      setEditing(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save health profile");
    } finally {
      setSaving(false);
    }
  };

  const bmi =
    profile && profile.height_cm > 0
      ? profile.weight_kg / Math.pow(profile.height_cm / 100, 2)
      : null;

  const medicalHistoryItems = profile?.medical_history
    ? profile.medical_history.split(/\n|,/).map((s) => s.trim()).filter(Boolean)
    : [];
  const allergyItems = profile?.allergies
    ? profile.allergies.split(/\n|,/).map((s) => s.trim()).filter(Boolean)
    : [];
  const familyHistoryItems = profile?.family_history
    ? profile.family_history.split(/\n|,/).map((s) => s.trim()).filter(Boolean)
    : [];

  return (
    <AppShell>
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Health Profile</h1>
        {!loading && (
          <Button
            variant={editing ? "primary" : "outline"}
            disabled={saving}
            onClick={() => (editing ? handleSave() : setEditing(true))}
          >
            <Pencil className="h-4 w-4" /> {saving ? "Saving..." : editing ? "Save Changes" : "Edit"}
          </Button>
        )}
      </div>

      {error && (
        <div className="mb-4 rounded-xl bg-red-50 px-4 py-2 text-sm text-red-600">{error}</div>
      )}

      {loading ? (
        <p className="text-sm text-gray-500">Loading your health profile...</p>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="flex flex-col items-center gap-4 text-center lg:col-span-1">
            <div className="flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent p-1">
              <div className="flex h-full w-full items-center justify-center rounded-full bg-white">
                <UserRound className="h-12 w-12 text-primary" />
              </div>
            </div>
            <div>
              <p className="text-lg font-bold text-gray-900 dark:text-white">{user?.full_name ?? ""}</p>
              <p className="text-sm text-gray-500">{user?.email ?? ""}</p>
            </div>
            {editing && (
              <Button size="sm" variant="secondary">Upload New Photo</Button>
            )}
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-xs font-medium text-gray-400">Age</p>
                {editing ? (
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={form.age}
                    onChange={(e) => setForm((f) => ({ ...f, age: e.target.value }))}
                    placeholder="Age"
                    className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
                  />
                ) : (
                  <p className="mt-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
                    {profile ? `${profile.age} years` : "—"}
                  </p>
                )}
              </div>
              <div>
                <p className="text-xs font-medium text-gray-400">Gender</p>
                {editing ? (
                  <select
                    value={form.gender}
                    onChange={(e) => setForm((f) => ({ ...f, gender: e.target.value as Gender }))}
                    className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
                  >
                    <option value="" disabled>Select</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                    <option value="prefer_not_to_say">Prefer not to say</option>
                  </select>
                ) : (
                  <p className="mt-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
                    {profile ? genderLabels[profile.gender] : "—"}
                  </p>
                )}
              </div>
              <div>
                <p className="text-xs font-medium text-gray-400">Height</p>
                {editing ? (
                  <input
                    type="number"
                    min={1}
                    step="0.1"
                    value={form.height_cm}
                    onChange={(e) => setForm((f) => ({ ...f, height_cm: e.target.value }))}
                    placeholder="Height (cm)"
                    className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
                  />
                ) : (
                  <p className="mt-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
                    {profile ? `${profile.height_cm} cm` : "—"}
                  </p>
                )}
              </div>
              <div>
                <p className="text-xs font-medium text-gray-400">Weight</p>
                {editing ? (
                  <input
                    type="number"
                    min={1}
                    step="0.1"
                    value={form.weight_kg}
                    onChange={(e) => setForm((f) => ({ ...f, weight_kg: e.target.value }))}
                    placeholder="Weight (kg)"
                    className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
                  />
                ) : (
                  <p className="mt-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
                    {profile ? `${profile.weight_kg} kg` : "—"}
                  </p>
                )}
              </div>
              <div>
                <p className="text-xs font-medium text-gray-400">BMI</p>
                <p className="mt-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {bmi ? bmi.toFixed(1) : "BMI unavailable"}
                </p>
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader><CardTitle>Medical History</CardTitle></CardHeader>
            {editing ? (
              <textarea
                value={form.medical_history}
                onChange={(e) => setForm((f) => ({ ...f, medical_history: e.target.value }))}
                placeholder="Medical history (optional)"
                rows={3}
                className="w-full resize-none rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            ) : medicalHistoryItems.length > 0 ? (
              <ul className="flex flex-col gap-2 text-sm text-gray-600 dark:text-gray-300">
                {medicalHistoryItems.map((m) => (
                  <li key={m} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" /> {m}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-400">No medical history on file</p>
            )}
          </Card>

          <Card>
            <CardHeader><CardTitle>Allergies</CardTitle></CardHeader>
            {editing ? (
              <textarea
                value={form.allergies}
                onChange={(e) => setForm((f) => ({ ...f, allergies: e.target.value }))}
                placeholder="Allergies (optional)"
                rows={3}
                className="w-full resize-none rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            ) : allergyItems.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {allergyItems.map((a) => (
                  <span key={a} className="rounded-full bg-red-50 px-3 py-1 text-xs font-medium text-red-600">{a}</span>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-400">No allergies on file</p>
            )}
          </Card>

          <Card>
            <CardHeader><CardTitle>Family History</CardTitle></CardHeader>
            {editing ? (
              <textarea
                value={form.family_history}
                onChange={(e) => setForm((f) => ({ ...f, family_history: e.target.value }))}
                placeholder="Family history (optional)"
                rows={3}
                className="w-full resize-none rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            ) : familyHistoryItems.length > 0 ? (
              <ul className="flex flex-col gap-2 text-sm text-gray-600 dark:text-gray-300">
                {familyHistoryItems.map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {f}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-400">No family history on file</p>
            )}
          </Card>
        </div>
      )}
    </AppShell>
  );
}
