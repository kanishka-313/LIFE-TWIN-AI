"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import DigitalTwinHologram from "@/components/DigitalTwinHologram";
import HeartbeatLine from "@/components/HeartbeatLine";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Brain,
  Activity,
  ShieldCheck,
  Stethoscope,
  Siren,
  Users,
  TrendingUp,
} from "lucide-react";

const features = [
  { icon: Brain, title: "AI Powered Insights", desc: "Deep learning models analyze your vitals continuously." },
  { icon: Activity, title: "Real-time Monitoring", desc: "Live vitals streamed from your connected wearables." },
  { icon: ShieldCheck, title: "Early Disease Detection", desc: "Predict risk before symptoms appear." },
  { icon: Stethoscope, title: "Personalized Recommendations", desc: "Custom diet, exercise and lifestyle plans." },
  { icon: Siren, title: "Emergency Support", desc: "Instant SOS alerts to family and nearby hospitals." },
  { icon: Users, title: "Doctor Collaboration", desc: "Share reports directly with your care team." },
  { icon: TrendingUp, title: "Better Health Outcomes", desc: "Track long-term trends and improve every month." },
];

const stats = [
  { label: "Active Users", value: "120K+" },
  { label: "Diseases Predicted", value: "38" },
  { label: "Partner Hospitals", value: "540+" },
  { label: "Prediction Accuracy", value: "96.8%" },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="mx-auto flex max-w-7xl flex-col-reverse items-center gap-12 px-4 py-16 sm:px-6 lg:flex-row lg:py-24 lg:px-8">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="flex-1 text-center lg:text-left"
        >
          <span className="inline-block rounded-full bg-primary/10 px-4 py-1 text-xs font-semibold text-primary">
            AI DIGITAL TWIN FOR HUMAN HEALTH
          </span>
          <h1 className="mt-4 text-4xl font-extrabold leading-tight text-gray-900 dark:text-white sm:text-6xl">
            <span className="text-gradient">LifeTwin AI</span>
          </h1>
          <p className="mt-4 text-lg font-medium text-gray-500 dark:text-gray-400">
            Your Health. AI Powered. Future Ready.
          </p>
          <HeartbeatLine className="mx-auto mt-6 h-14 w-full max-w-sm lg:mx-0" />
          <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row lg:justify-start">
            <Link href="/signup"><Button size="lg">Get Started</Button></Link>
            <Link href="/dashboard"><Button size="lg" variant="secondary">View Dashboard</Button></Link>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-6 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label}>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{s.value}</p>
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400">{s.label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="flex-1"
        >
          <DigitalTwinHologram />
        </motion.div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Why LifeTwin AI</h2>
          <p className="mt-2 text-gray-500 dark:text-gray-400">
            A full AI digital twin of your body — predicting, preventing and protecting.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className="h-full">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent">
                  <f.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-base font-semibold text-gray-900 dark:text-white">{f.title}</h3>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{f.desc}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-4 pb-24 sm:px-6 lg:px-8">
        <Card className="flex flex-col items-center gap-4 bg-gradient-to-br from-primary to-accent p-12 text-center text-white">
          <h2 className="text-3xl font-bold">Ready to meet your digital twin?</h2>
          <p className="max-w-xl text-white/90">
            Join thousands using LifeTwin AI to predict, prevent, and protect their health every single day.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90">
              Create Free Account
            </Button>
          </Link>
        </Card>
      </section>

      <Footer />
    </div>
  );
}
