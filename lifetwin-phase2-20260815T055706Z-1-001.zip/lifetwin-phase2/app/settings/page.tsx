"use client";

import { useState } from "react";
import AppShell from "@/components/AppShell";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Moon, Shield, Globe, LogOut } from "lucide-react";

function Toggle({ defaultOn = false }: { defaultOn?: boolean }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <button
      onClick={() => setOn((o) => !o)}
      className={`h-6 w-11 rounded-full transition-colors ${on ? "bg-primary" : "bg-gray-200"}`}
    >
      <span
        className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white shadow transition-transform ${
          on ? "translate-x-5" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

const notifPrefs = ["Abnormal vitals alerts", "Weekly health report", "Medication reminders", "Doctor messages"];

export default function SettingsPage() {
  return (
    <AppShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Manage your account, preferences and privacy.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle><Bell className="mr-2 inline h-4 w-4" />Notifications</CardTitle></CardHeader>
          <div className="flex flex-col gap-4">
            {notifPrefs.map((p, i) => (
              <div key={p} className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-300">
                {p}
                <Toggle defaultOn={i < 2} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle><Moon className="mr-2 inline h-4 w-4" />Appearance</CardTitle></CardHeader>
          <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-300">
            Dark Mode
            <Toggle />
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle><Shield className="mr-2 inline h-4 w-4" />Privacy & Security</CardTitle></CardHeader>
          <div className="flex flex-col gap-4 text-sm text-gray-600 dark:text-gray-300">
            <div className="flex items-center justify-between">Share data with doctors <Toggle defaultOn /></div>
            <div className="flex items-center justify-between">Two-factor authentication <Toggle /></div>
            <Button size="sm" variant="outline" className="w-fit">Change Password</Button>
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle><Globe className="mr-2 inline h-4 w-4" />Preferences</CardTitle></CardHeader>
          <div className="flex flex-col gap-4 text-sm text-gray-600 dark:text-gray-300">
            <div className="flex items-center justify-between">
              Units
              <select className="rounded-lg border border-gray-200 px-2 py-1 text-xs outline-none">
                <option>Metric (kg, cm)</option>
                <option>Imperial (lb, in)</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              Language
              <select className="rounded-lg border border-gray-200 px-2 py-1 text-xs outline-none">
                <option>English</option>
                <option>Hindi</option>
                <option>Tamil</option>
              </select>
            </div>
          </div>
        </Card>
      </div>

      <Button variant="danger" className="mt-8"><LogOut className="h-4 w-4" /> Sign Out</Button>
    </AppShell>
  );
}
