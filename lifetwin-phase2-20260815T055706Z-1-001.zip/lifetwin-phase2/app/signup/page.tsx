"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { HeartPulse, Mail, Lock, User, Ruler, Weight, Calendar, FileText, AlertTriangle, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { ApiError } from "@/lib/api";
import api, { Gender } from "@/lib/api";

export default function SignupPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Account details — no defaults.
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Personal / health details — no defaults. Empty until the user enters them.
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<Gender | "">("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [medicalHistory, setMedicalHistory] = useState("");
  const [allergies, setAllergies] = useState("");
  const [familyHistory, setFamilyHistory] = useState("");

  const { signup } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const ageNum = Number(age);
    const heightNum = Number(height);
    const weightNum = Number(weight);

    if (!gender) {
      setError("Please select a gender.");
      return;
    }
    if (!Number.isFinite(ageNum) || ageNum <= 0) {
      setError("Please enter a valid age.");
      return;
    }
    if (!Number.isFinite(heightNum) || heightNum <= 0) {
      setError("Please enter a valid height.");
      return;
    }
    if (!Number.isFinite(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight.");
      return;
    }

    setLoading(true);
    try {
      await signup({
        full_name: fullName,
        email,
        password,
        confirm_password: password,
        age: ageNum,
        gender,
        height_cm: heightNum,
        weight_kg: weightNum,
        medical_history: medicalHistory || null,
        allergies: allergies || null,
        family_history: familyHistory || null,
      });
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to create account");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    try {
      const { auth_url } = await api.auth.googleLoginUrl();
      window.location.href = auth_url;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Google sign-up is not configured");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-accent/5 via-white to-primary/5 px-4 py-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md rounded-card border border-white/60 bg-white/80 p-8 shadow-soft backdrop-blur-xl"
      >
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-soft">
            <HeartPulse className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Create your account</h1>
          <p className="text-sm text-gray-500">Start your AI health journey today</p>
        </div>

        {error && (
          <div className="mb-4 rounded-xl bg-red-50 px-4 py-2 text-sm text-red-600">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">Account details</p>

          <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <User className="h-4 w-4 text-gray-400" />
            <input
              type="text"
              required
              placeholder="Full name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full bg-transparent text-sm outline-none"
            />
          </label>
          <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <Mail className="h-4 w-4 text-gray-400" />
            <input
              type="email"
              required
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-transparent text-sm outline-none"
            />
          </label>
          <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <Lock className="h-4 w-4 text-gray-400" />
            <input
              type="password"
              required
              placeholder="Create password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent text-sm outline-none"
            />
          </label>
          <p className="text-xs text-gray-400">
            Must be 8+ characters with an uppercase letter, lowercase letter, and a number.
          </p>

          <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-gray-400">Personal &amp; health details</p>

          <div className="grid grid-cols-2 gap-3">
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Calendar className="h-4 w-4 shrink-0 text-gray-400" />
              <input
                type="number"
                min={1}
                max={120}
                required
                placeholder="Age"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Users className="h-4 w-4 shrink-0 text-gray-400" />
              <select
                required
                value={gender}
                onChange={(e) => setGender(e.target.value as Gender)}
                className="w-full bg-transparent text-sm outline-none text-gray-700"
              >
                <option value="" disabled>
                  Gender
                </option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
                <option value="prefer_not_to_say">Prefer not to say</option>
              </select>
            </label>
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Ruler className="h-4 w-4 shrink-0 text-gray-400" />
              <input
                type="number"
                min={1}
                step="0.1"
                required
                placeholder="Height (cm)"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <label className="flex items-center gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
              <Weight className="h-4 w-4 shrink-0 text-gray-400" />
              <input
                type="number"
                min={1}
                step="0.1"
                required
                placeholder="Weight (kg)"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
          </div>

          <label className="flex items-start gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <FileText className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
            <textarea
              placeholder="Medical history (optional)"
              value={medicalHistory}
              onChange={(e) => setMedicalHistory(e.target.value)}
              rows={2}
              className="w-full resize-none bg-transparent text-sm outline-none"
            />
          </label>
          <label className="flex items-start gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
            <textarea
              placeholder="Allergies (optional)"
              value={allergies}
              onChange={(e) => setAllergies(e.target.value)}
              rows={2}
              className="w-full resize-none bg-transparent text-sm outline-none"
            />
          </label>
          <label className="flex items-start gap-3 rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-primary">
            <Users className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
            <textarea
              placeholder="Family history (optional)"
              value={familyHistory}
              onChange={(e) => setFamilyHistory(e.target.value)}
              rows={2}
              className="w-full resize-none bg-transparent text-sm outline-none"
            />
          </label>

          <label className="flex items-center gap-2 text-xs text-gray-500">
            <input type="checkbox" required className="rounded" /> I agree to the Terms and Privacy Policy
          </label>
          <Button type="submit" size="lg" className="mt-2 w-full" disabled={loading}>
            {loading ? "Creating account..." : "Create Account"}
          </Button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-gray-400">
          <div className="h-px flex-1 bg-gray-200" />
          OR
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        <Button type="button" variant="outline" size="lg" className="w-full" onClick={handleGoogleSignup}>
          Continue with Google
        </Button>

        <p className="mt-6 text-center text-sm text-gray-500">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-primary">Sign in</Link>
        </p>
      </motion.div>
    </div>
  );
}
