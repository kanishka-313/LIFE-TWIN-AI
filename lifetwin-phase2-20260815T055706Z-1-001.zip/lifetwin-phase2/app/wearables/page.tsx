"use client";

import { useState } from "react";
import AppShell from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { wearableDevices as initialDevices } from "@/lib/data";
import { Watch, BatteryMedium, RefreshCw } from "lucide-react";

export default function WearablesPage() {
  const [devices, setDevices] = useState(initialDevices);
  const [syncingId, setSyncingId] = useState<string | null>(null);

  const handleSync = (id: string) => {
    setSyncingId(id);
    setTimeout(() => {
      setDevices((prev) =>
        prev.map((d) => (d.id === id ? { ...d, lastSync: "just now", connected: true } : d))
      );
      setSyncingId(null);
    }, 1000);
  };

  return (
    <AppShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Wearable Devices</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Manage all devices connected to your LifeTwin AI digital twin.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {devices.map((dev) => (
          <Card key={dev.id} className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10">
                <Watch className="h-5 w-5 text-primary" />
              </div>
              <Badge status={dev.connected ? "low" : "high"}>{dev.connected ? "Connected" : "Disconnected"}</Badge>
            </div>
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">{dev.name}</p>
              <p className="text-xs text-gray-500">{dev.brand} · Last sync {dev.lastSync}</p>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <BatteryMedium className="h-4 w-4" />
              <div className="h-1.5 w-full rounded-full bg-gray-100">
                <div
                  className={`h-full rounded-full ${dev.battery > 30 ? "bg-accent" : "bg-red-500"}`}
                  style={{ width: `${dev.battery}%` }}
                />
              </div>
              <span>{dev.battery}%</span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleSync(dev.id)}
              disabled={syncingId === dev.id}
            >
              <RefreshCw className={`h-4 w-4 ${syncingId === dev.id ? "animate-spin" : ""}`} />
              {syncingId === dev.id ? "Syncing..." : "Sync Now"}
            </Button>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}
