import secrets

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, limiter
from app.core.config import get_settings
from app.core.security import create_access_token
from app.db.database import get_db
from app.db.models import User
from app.schemas.auth import (
    ForgotPasswordRequest,
    LoginRequest,
    ResetPasswordRequest,
    SignupRequest,
    TokenResponse,
    UserOut,
    VerifyOtpRequest,
)
from app.services.auth_service import (
    AuthError,
    authenticate_user,
    create_user,
    find_or_create_google_user,
    get_user_by_email,
    set_new_password,
)
from app.services.email_service import EmailNotConfiguredError
from app.services.google_oauth_service import (
    GoogleOAuthNotConfiguredError,
    build_authorization_url,
    exchange_code_for_userinfo,
)
from app.services.otp_service import OtpError, consume_otp, issue_otp, verify_otp

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()

# In-memory CSRF state store for the OAuth redirect flow. For multi-instance
# production deployments, back this with Redis instead.
_oauth_states: set[str] = set()


def _user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        full_name=user.full_name,
        email=user.email,
        is_email_verified=user.is_email_verified,
        has_password=user.password_hash is not None,
    )


def _api_error(status_code: int, message: str, code: str):
    raise HTTPException(status_code=status_code, detail={"success": False, "message": message, "code": code})


@router.post("/signup", response_model=TokenResponse, status_code=201)
@limiter.limit("10/minute")
def signup(request: Request, payload: SignupRequest, db: Session = Depends(get_db)):
    try:
        user = create_user(db, payload)
    except AuthError as e:
        _api_error(e.status_code, e.message, e.code)

    # Best-effort verification email — signup still succeeds if SMTP isn't configured yet,
    # but the caller is told so explicitly rather than us pretending it was sent.
    email_warning = None
    try:
        issue_otp(db, user, purpose="email_verification")
    except EmailNotConfiguredError:
        email_warning = "SMTP is not configured; verification email was not sent."
    except OtpError:
        pass

    token = create_access_token(subject=user.id)
    response = TokenResponse(access_token=token, user=_user_out(user))
    if email_warning:
        # Surface the warning without breaking the typed response contract.
        return {**response.model_dump(), "warning": email_warning}
    return response


@router.post("/login", response_model=TokenResponse)
@limiter.limit("10/minute")
def login(request: Request, payload: LoginRequest, db: Session = Depends(get_db)):
    try:
        user = authenticate_user(db, payload.email, payload.password)
    except AuthError as e:
        _api_error(e.status_code, e.message, e.code)

    token = create_access_token(subject=user.id)
    return TokenResponse(access_token=token, user=_user_out(user))


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return _user_out(current_user)


# ---------------------------------------------------------------------------
# Google OAuth
# ---------------------------------------------------------------------------
@router.get("/google/login")
def google_login():
    state = secrets.token_urlsafe(24)
    _oauth_states.add(state)
    try:
        url = build_authorization_url(state)
    except GoogleOAuthNotConfiguredError as e:
        _api_error(503, str(e), "GOOGLE_OAUTH_NOT_CONFIGURED")
    return {"auth_url": url}


@router.get("/google/callback")
async def google_callback(code: str, state: str, db: Session = Depends(get_db)):
    if state not in _oauth_states:
        _api_error(400, "Invalid OAuth state", "INVALID_STATE")
    _oauth_states.discard(state)

    try:
        userinfo = await exchange_code_for_userinfo(code)
    except GoogleOAuthNotConfiguredError as e:
        _api_error(503, str(e), "GOOGLE_OAUTH_NOT_CONFIGURED")
    except Exception:
        _api_error(400, "Failed to authenticate with Google", "GOOGLE_AUTH_FAILED")

    if not userinfo.get("email_verified", False):
        _api_error(400, "Google account email is not verified", "GOOGLE_EMAIL_UNVERIFIED")

    user = find_or_create_google_user(
        db,
        google_id=userinfo["sub"],
        email=userinfo["email"],
        full_name=userinfo.get("name", ""),
    )
    token = create_access_token(subject=user.id)

    # Hand the token back to the frontend via a redirect + fragment, so it
    # never has to touch the query string / server logs.
    redirect_url = f"{settings.FRONTEND_URL}/auth/callback#access_token={token}"
    return RedirectResponse(redirect_url)


# ---------------------------------------------------------------------------
# Forgot password (email OTP)
# ---------------------------------------------------------------------------
@router.post("/forgot-password")
@limiter.limit("5/minute")
def forgot_password(request: Request, payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, payload.email)
    # Always return a generic success message so we never leak which emails exist.
    generic_response = {"success": True, "message": "If that email exists, a code has been sent."}
    if not user:
        return generic_response

    try:
        issue_otp(db, user, purpose="password_reset")
    except OtpError as e:
        _api_error(429, e.message, e.code)
    except EmailNotConfiguredError as e:
        _api_error(503, str(e), "SMTP_NOT_CONFIGURED")

    return generic_response


@router.post("/verify-otp")
@limiter.limit("10/minute")
def verify_otp_endpoint(request: Request, payload: VerifyOtpRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, payload.email)
    if not user:
        _api_error(400, "Invalid code", "INVALID_OTP")

    try:
        verify_otp(db, user, payload.otp, purpose=payload.purpose)
    except OtpError as e:
        _api_error(400, e.message, e.code)

    return {"success": True, "message": "Code verified"}


@router.post("/reset-password")
@limiter.limit("10/minute")
def reset_password(request: Request, payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, payload.email)
    if not user:
        _api_error(400, "Invalid code", "INVALID_OTP")

    try:
        record = verify_otp(db, user, payload.otp, purpose="password_reset")
        consume_otp(db, record)
    except OtpError as e:
        _api_error(400, e.message, e.code)

    set_new_password(db, user, payload.new_password)
    return {"success": True, "message": "Password has been reset. Please log in."}
