from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.database import get_db
from app.db.models import User
from app.schemas.health import HealthProfileOut, HealthProfileUpdateRequest
from app.services.health_service import get_health_profile, update_health_profile

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/profile", response_model=HealthProfileOut | None)
def read_health_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Returns the authenticated user's own health profile — never another
    user's. Returns null if none exists yet (frontend should render empty
    fields, never fake values).
    """
    profile = get_health_profile(db, current_user)
    if profile is None:
        return None
    return HealthProfileOut.model_validate(profile)


@router.put("/profile", response_model=HealthProfileOut)
def edit_health_profile(
    payload: HealthProfileUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    profile = update_health_profile(db, current_user, payload)
    return HealthProfileOut.model_validate(profile)
