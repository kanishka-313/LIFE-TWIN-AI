import logging

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.api import auth, health
from app.api.deps import limiter
from app.core.config import get_settings

logging.basicConfig(level=logging.INFO)
settings = get_settings()

app = FastAPI(
    title="LifeTwin AI API",
    description="Backend API for LifeTwin AI — a health monitoring and risk-screening platform. "
    "Not a diagnostic medical device.",
    version="0.2.0",
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc: HTTPException):
    # Normalize error shape: {"success": false, "message": ..., "code": ...}
    detail = exc.detail
    if isinstance(detail, dict) and "message" in detail:
        body = {"success": False, "message": detail["message"], "code": detail.get("code", "ERROR")}
    else:
        body = {"success": False, "message": str(detail), "code": "ERROR"}
    return JSONResponse(status_code=exc.status_code, content=body)


@app.get("/health")
def health_check():
    return {"status": "ok", "environment": settings.ENVIRONMENT}


app.include_router(auth.router)
app.include_router(health.router)
