import re
from enum import Enum

from pydantic import BaseModel, EmailStr, field_validator

PASSWORD_MIN_LENGTH = 8

# Sensible bounds — reject obviously-invalid input, but never used as defaults.
MIN_AGE = 1
MAX_AGE = 120
MIN_HEIGHT_CM = 30.0
MAX_HEIGHT_CM = 300.0
MIN_WEIGHT_KG = 1.0
MAX_WEIGHT_KG = 500.0


class Gender(str, Enum):
    male = "male"
    female = "female"
    other = "other"
    prefer_not_to_say = "prefer_not_to_say"


def _validate_password_strength(value: str) -> str:
    if len(value) < PASSWORD_MIN_LENGTH:
        raise ValueError(f"Password must be at least {PASSWORD_MIN_LENGTH} characters long")
    if not re.search(r"[A-Z]", value):
        raise ValueError("Password must contain at least one uppercase letter")
    if not re.search(r"[a-z]", value):
        raise ValueError("Password must contain at least one lowercase letter")
    if not re.search(r"\d", value):
        raise ValueError("Password must contain at least one number")
    return value


class SignupRequest(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    confirm_password: str

    # --- Health / personal details, required at signup. No defaults. ---
    age: int
    gender: Gender
    height_cm: float
    weight_kg: float
    medical_history: str | None = None
    allergies: str | None = None
    family_history: str | None = None

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)

    @field_validator("confirm_password")
    @classmethod
    def passwords_match(cls, v: str, info):
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("Passwords do not match")
        return v

    @field_validator("full_name")
    @classmethod
    def name_not_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Full name is required")
        return v.strip()

    @field_validator("age")
    @classmethod
    def age_in_range(cls, v: int) -> int:
        if v < MIN_AGE or v > MAX_AGE:
            raise ValueError(f"Age must be between {MIN_AGE} and {MAX_AGE}")
        return v

    @field_validator("height_cm")
    @classmethod
    def height_in_range(cls, v: float) -> float:
        if v < MIN_HEIGHT_CM or v > MAX_HEIGHT_CM:
            raise ValueError(f"Height must be between {MIN_HEIGHT_CM} and {MAX_HEIGHT_CM} cm")
        return v

    @field_validator("weight_kg")
    @classmethod
    def weight_in_range(cls, v: float) -> float:
        if v < MIN_WEIGHT_KG or v > MAX_WEIGHT_KG:
            raise ValueError(f"Weight must be between {MIN_WEIGHT_KG} and {MAX_WEIGHT_KG} kg")
        return v

    @field_validator("medical_history", "allergies", "family_history")
    @classmethod
    def blank_to_none(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        return v or None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    id: str
    full_name: str
    email: EmailStr
    is_email_verified: bool
    has_password: bool

    model_config = {"from_attributes": True}


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class VerifyOtpRequest(BaseModel):
    email: EmailStr
    otp: str
    purpose: str = "password_reset"


class ResetPasswordRequest(BaseModel):
    email: EmailStr
    otp: str
    new_password: str
    confirm_new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)

    @field_validator("confirm_new_password")
    @classmethod
    def passwords_match(cls, v: str, info):
        if "new_password" in info.data and v != info.data["new_password"]:
            raise ValueError("Passwords do not match")
        return v


class GoogleAuthUrlResponse(BaseModel):
    auth_url: str


class ApiError(BaseModel):
    success: bool = False
    message: str
    code: str
