from pydantic import BaseModel, field_validator

from app.schemas.auth import (
    MAX_AGE,
    MAX_HEIGHT_CM,
    MAX_WEIGHT_KG,
    MIN_AGE,
    MIN_HEIGHT_CM,
    MIN_WEIGHT_KG,
    Gender,
)


class HealthProfileOut(BaseModel):
    age: int
    gender: Gender
    height_cm: float
    weight_kg: float
    medical_history: str | None
    allergies: str | None
    family_history: str | None

    model_config = {"from_attributes": True}


class HealthProfileUpdateRequest(BaseModel):
    age: int
    gender: Gender
    height_cm: float
    weight_kg: float
    medical_history: str | None = None
    allergies: str | None = None
    family_history: str | None = None

    @field_validator("age")
    @classmethod
    def age_in_range(cls, v: int) -> int:
        if v < MIN_AGE or v > MAX_AGE:
            raise ValueError(f"Age must be between {MIN_AGE} and {MAX_AGE}")
        return v

    @field_validator("height_cm")
    @classmethod
    def height_in_range(cls, v: float) -> float:
        if v < MIN_HEIGHT_CM or v > MAX_HEIGHT_CM:
            raise ValueError(f"Height must be between {MIN_HEIGHT_CM} and {MAX_HEIGHT_CM} cm")
        return v

    @field_validator("weight_kg")
    @classmethod
    def weight_in_range(cls, v: float) -> float:
        if v < MIN_WEIGHT_KG or v > MAX_WEIGHT_KG:
            raise ValueError(f"Weight must be between {MIN_WEIGHT_KG} and {MAX_WEIGHT_KG} kg")
        return v

    @field_validator("medical_history", "allergies", "family_history")
    @classmethod
    def blank_to_none(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        return v or None
