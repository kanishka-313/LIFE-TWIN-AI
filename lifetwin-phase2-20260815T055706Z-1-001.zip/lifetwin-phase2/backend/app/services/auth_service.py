from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password, verify_password
from app.db.models import HealthProfile, User
from app.schemas.auth import SignupRequest


class AuthError(Exception):
    def __init__(self, message: str, code: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code


def get_user_by_email(db: Session, email: str) -> User | None:
    stmt = select(User).where(User.email == email.lower())
    return db.execute(stmt).scalars().first()


def create_user(db: Session, payload: SignupRequest) -> User:
    """
    Creates the user AND their health profile in a single transaction.
    If either fails, nothing is committed — there is no path that leaves a
    user row without a matching health profile.
    """
    if get_user_by_email(db, payload.email):
        raise AuthError("An account with this email already exists", "EMAIL_TAKEN", 409)

    try:
        user = User(
            full_name=payload.full_name,
            email=payload.email.lower(),
            password_hash=hash_password(payload.password),
            is_email_verified=False,
        )
        db.add(user)
        db.flush()  # assigns user.id without committing yet

        profile = HealthProfile(
            user_id=user.id,
            age=payload.age,
            gender=payload.gender.value,
            height_cm=payload.height_cm,
            weight_kg=payload.weight_kg,
            medical_history=payload.medical_history,
            allergies=payload.allergies,
            family_history=payload.family_history,
        )
        db.add(profile)
        db.commit()
    except Exception:
        db.rollback()
        raise AuthError(
            "Could not create account. Please try again.", "SIGNUP_FAILED", 500
        )

    db.refresh(user)
    return user


def authenticate_user(db: Session, email: str, password: str) -> User:
    user = get_user_by_email(db, email)
    if not user or not user.password_hash:
        raise AuthError("Invalid email or password", "INVALID_CREDENTIALS", 401)
    if not verify_password(password, user.password_hash):
        raise AuthError("Invalid email or password", "INVALID_CREDENTIALS", 401)
    if not user.is_active:
        raise AuthError("This account has been disabled", "ACCOUNT_DISABLED", 403)
    return user


def find_or_create_google_user(db: Session, google_id: str, email: str, full_name: str) -> User:
    stmt = select(User).where(User.google_id == google_id)
    user = db.execute(stmt).scalars().first()
    if user:
        return user

    # Link to an existing email/password account if one exists.
    existing = get_user_by_email(db, email)
    if existing:
        existing.google_id = google_id
        existing.is_email_verified = True
        db.commit()
        db.refresh(existing)
        return existing

    user = User(
        full_name=full_name or email.split("@")[0],
        email=email.lower(),
        google_id=google_id,
        is_email_verified=True,
        password_hash=None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def set_new_password(db: Session, user: User, new_password: str) -> None:
    user.password_hash = hash_password(new_password)
    db.commit()
