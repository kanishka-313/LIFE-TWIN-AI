"""
Real SMTP email delivery. If SMTP is not configured, sending raises
EmailNotConfiguredError instead of silently pretending to succeed —
per project requirement #46 ("never fake successful external operations").
"""
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from app.core.config import get_settings

logger = logging.getLogger("lifetwin.email")
settings = get_settings()


class EmailNotConfiguredError(RuntimeError):
    pass


def send_email(to_email: str, subject: str, html_body: str, text_body: str | None = None) -> None:
    if not settings.smtp_configured:
        raise EmailNotConfiguredError(
            "SMTP is not configured. Set SMTP_HOST, SMTP_USERNAME and SMTP_PASSWORD "
            "in your environment to enable outgoing email."
        )

    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = settings.SMTP_FROM
    message["To"] = to_email

    if text_body:
        message.attach(MIMEText(text_body, "plain"))
    message.attach(MIMEText(html_body, "html"))

    with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
        server.starttls()
        server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
        server.sendmail(settings.SMTP_FROM, [to_email], message.as_string())

    # Never log OTP or password-reset content — only that a send occurred.
    logger.info("Email sent to %s (subject=%r)", to_email, subject)


def send_otp_email(to_email: str, otp: str, purpose: str) -> None:
    if purpose == "email_verification":
        subject = "Verify your LifeTwin AI account"
        heading = "Verify your email"
    else:
        subject = "Your LifeTwin AI password reset code"
        heading = "Reset your password"

    html_body = f"""
    <div style="font-family:sans-serif;max-width:480px;margin:auto">
      <h2>{heading}</h2>
      <p>Your one-time code is:</p>
      <p style="font-size:28px;font-weight:bold;letter-spacing:4px">{otp}</p>
      <p>This code expires in {settings.OTP_EXPIRE_MINUTES} minutes. If you did not request this, you can ignore this email.</p>
    </div>
    """
    send_email(to_email, subject, html_body, text_body=f"Your LifeTwin AI code is {otp}")
