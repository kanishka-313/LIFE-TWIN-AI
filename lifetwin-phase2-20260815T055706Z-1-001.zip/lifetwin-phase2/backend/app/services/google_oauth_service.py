"""
Real Google OAuth 2.0 authorization-code flow.

Setup required in Google Cloud Console (documented in README.md):
1. Create an OAuth 2.0 Client ID (Web application).
2. Add GOOGLE_REDIRECT_URI as an authorized redirect URI.
3. Add your frontend origin as an authorized JavaScript origin.
4. Put the client ID/secret in your backend .env — never in frontend code.
"""
from urllib.parse import urlencode

import httpx

from app.core.config import get_settings

settings = get_settings()

GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_ENDPOINT = "https://www.googleapis.com/oauth2/v3/userinfo"


class GoogleOAuthNotConfiguredError(RuntimeError):
    pass


def build_authorization_url(state: str) -> str:
    if not settings.google_oauth_configured:
        raise GoogleOAuthNotConfiguredError(
            "Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET."
        )
    params = {
        "client_id": settings.GOOGLE_CLIENT_ID,
        "redirect_uri": settings.GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": "openid email profile",
        "access_type": "offline",
        "prompt": "select_account",
        "state": state,
    }
    return f"{GOOGLE_AUTH_ENDPOINT}?{urlencode(params)}"


async def exchange_code_for_userinfo(code: str) -> dict:
    if not settings.google_oauth_configured:
        raise GoogleOAuthNotConfiguredError("Google OAuth is not configured.")

    async with httpx.AsyncClient(timeout=10) as client:
        token_resp = await client.post(
            GOOGLE_TOKEN_ENDPOINT,
            data={
                "code": code,
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "redirect_uri": settings.GOOGLE_REDIRECT_URI,
                "grant_type": "authorization_code",
            },
        )
        token_resp.raise_for_status()
        access_token = token_resp.json()["access_token"]

        userinfo_resp = await client.get(
            GOOGLE_USERINFO_ENDPOINT,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        userinfo_resp.raise_for_status()
        return userinfo_resp.json()  # {sub, email, email_verified, name, picture, ...}
