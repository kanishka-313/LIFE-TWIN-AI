from sqlalchemy.orm import Session

from app.db.models import HealthProfile, User
from app.schemas.health import HealthProfileUpdateRequest


def get_health_profile(db: Session, user: User) -> HealthProfile | None:
    return user.health_profile


def update_health_profile(
    db: Session, user: User, payload: HealthProfileUpdateRequest
) -> HealthProfile:
    profile = user.health_profile
    if profile is None:
        # Shouldn't normally happen (signup always creates one), but handle
        # gracefully rather than assuming/guessing values.
        profile = HealthProfile(user_id=user.id)
        db.add(profile)

    profile.age = payload.age
    profile.gender = payload.gender.value
    profile.height_cm = payload.height_cm
    profile.weight_kg = payload.weight_kg
    profile.medical_history = payload.medical_history
    profile.allergies = payload.allergies
    profile.family_history = payload.family_history

    db.commit()
    db.refresh(profile)
    return profile
