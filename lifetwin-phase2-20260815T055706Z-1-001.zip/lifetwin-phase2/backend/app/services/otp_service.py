from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import generate_otp, hash_password, verify_password
from app.db.models import PasswordResetOTP, User
from app.services.email_service import send_otp_email

settings = get_settings()


class OtpError(Exception):
    def __init__(self, message: str, code: str):
        super().__init__(message)
        self.message = message
        self.code = code


def _latest_otp(db: Session, user_id: str, purpose: str) -> PasswordResetOTP | None:
    stmt = (
        select(PasswordResetOTP)
        .where(
            PasswordResetOTP.user_id == user_id,
            PasswordResetOTP.purpose == purpose,
            PasswordResetOTP.consumed.is_(False),
        )
        .order_by(PasswordResetOTP.created_at.desc())
    )
    return db.execute(stmt).scalars().first()


def issue_otp(db: Session, user: User, purpose: str = "password_reset") -> None:
    """Generates an OTP, stores only its hash, and emails it. Enforces resend cooldown."""
    existing = _latest_otp(db, user.id, purpose)
    if existing:
        seconds_since_created = (datetime.now(timezone.utc) - existing.created_at.replace(tzinfo=timezone.utc)).total_seconds()
        if seconds_since_created < settings.OTP_RESEND_COOLDOWN_SECONDS:
            wait = int(settings.OTP_RESEND_COOLDOWN_SECONDS - seconds_since_created)
            raise OtpError(f"Please wait {wait}s before requesting another code", "OTP_COOLDOWN")
        existing.consumed = True  # invalidate previous code

    otp_plain = generate_otp()
    record = PasswordResetOTP(
        user_id=user.id,
        otp_hash=hash_password(otp_plain),
        purpose=purpose,
        max_attempts=settings.OTP_MAX_ATTEMPTS,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=settings.OTP_EXPIRE_MINUTES),
    )
    db.add(record)
    db.commit()

    # Sent only via email — never returned in the API response, never logged.
    send_otp_email(user.email, otp_plain, purpose)


def verify_otp(db: Session, user: User, otp_plain: str, purpose: str = "password_reset") -> PasswordResetOTP:
    record = _latest_otp(db, user.id, purpose)
    if record is None:
        raise OtpError("No active code found. Please request a new one.", "OTP_NOT_FOUND")

    if datetime.now(timezone.utc) > record.expires_at.replace(tzinfo=timezone.utc):
        raise OtpError("This code has expired. Please request a new one.", "OTP_EXPIRED")

    if record.attempts >= record.max_attempts:
        record.consumed = True  # explicitly invalidate — this code can never be verified again
        db.commit()
        raise OtpError("Too many incorrect attempts. Please request a new code.", "OTP_LOCKED")

    if not verify_password(otp_plain, record.otp_hash):
        record.attempts += 1
        if record.attempts >= record.max_attempts:
            record.consumed = True
        db.commit()
        raise OtpError("Invalid code", "INVALID_OTP")

    return record


def consume_otp(db: Session, record: PasswordResetOTP) -> None:
    record.consumed = True
    db.commit()
