export type RiskLevel = "low" | "medium" | "high";

export interface VitalStat {
  id: string;
  label: string;
  value: string;
  unit: string;
  status: RiskLevel;
  trend: number[];
  icon: string;
}

export interface DiseaseRisk {
  id: string;
  name: string;
  riskPercent: number;
  confidence: number;
  level: RiskLevel;
  recommendation: string;
}

export interface WearableDevice {
  id: string;
  name: string;
  brand: string;
  connected: boolean;
  battery: number;
  lastSync: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "ai";
  content: string;
  timestamp: string;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  healthScore: number;
  riskLevel: RiskLevel;
  vitals: { heartRate: number; bp: string; spo2: number };
  lastVisit: string;
}

export interface TrendPoint {
  label: string;
  value: number;
}
